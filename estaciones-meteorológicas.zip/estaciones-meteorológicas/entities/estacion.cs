public class Estacion
{
    private int id;
    private string nombre;
    private string localidad;
    private bool activa;

    public int Id { get => id; set => id = value; }
    public string Nombre { get => nombre; set => nombre = value; }
    public string Localidad { get => localidad; set => localidad = value; }
    public bool Activa { get => activa; set => activa = value; }
}