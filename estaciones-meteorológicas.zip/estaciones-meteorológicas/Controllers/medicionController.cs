using System.Runtime.ExceptionServices;
using Estaciones_Meteorológicas.Controllers;
using Microsoft.AspNetCore.Mvc;

namespace mediciones_Meteorológicas.Controllers;

[ApiController]
[Route("[controller]")]
public class medicionController : ControllerBase
{
    private readonly ILogger<medicionController> _logger;

    private readonly List<Medicion> mediciones = new List<Medicion>
    {
        new Medicion { Id = 1, EstacionId = 1, Temperatura = 25.5, Humedad = 60.0, VelocidadViento = 10.0, FechaHora = DateTime.Now }
    };

    public medicionController(ILogger<medicionController> logger)
    {
        _logger = logger;
    }

    [HttpPost("registrar")]
    public IActionResult create([FromBody] Medicion medicion)
    {
        try
        {

            if (medicion == null)
            {
                return NotFound("La medicion no puede ser nula.");
            }
            if (medicion.Humedad < 1 || medicion.Humedad > 100)
            {
                return NotFound("La humedad debe estar entre 1 y 100.");
            }
            if(medicion.VelocidadViento < 0)
            {
                return NotFound("La velocidad del viento no puede ser negativa.");
            }
            if (medicion.FechaHora > DateTime.Now)
            {
                return NotFound("La fecha y hora de la medición no puede ser futura.");
            }
            mediciones.Add(medicion);
            return Ok("Medicíon registrada correctamente.");
        }
        catch
        {
            return StatusCode(500, "Error en el servidor");
        }
    }

    [HttpGet("all")]
    public IActionResult GetAll()
    {
        try
        {
            if(mediciones is null)
            {
                return NotFound("No hay mediciones registradas");
            }
            return Ok(mediciones);
        }
        catch
        {
            return StatusCode(500, "Error en el servidor");
        }
    }

    [HttpGet("{idEstacion}")]
    public IActionResult GetById(int idEstacion)
    {
        try
        {
            var medicionEstacion = mediciones.Where(x => x.EstacionId == idEstacion).ToList();
            if(medicionEstacion is null)
            {
                return NotFound("No hay medicion con esa estacion");
            }
            return Ok(medicionEstacion);
        }
        catch
        {
            return StatusCode(500, "Error en el servidor");
        }
    }

    [HttpGet("Estacion")]
    public IActionResult GetByEstacion(double temperatura)
    {
        try
        {
            var medicion = mediciones.Where(x => x.Temperatura > temperatura).ToList();
            if(medicion is null)
            {
                return NotFound("No hay temperaturas mayores a la ingresada");
            }
            return Ok(medicion);
        }
        catch
        {
            return StatusCode(500, "Error en el servidor");
        }
    }

    [HttpGet("Temperatura mas alta")]
    public IActionResult GetByTemperatura()
    {
        try
        {
            var medicion = mediciones.OrderBy(x => x.Temperatura).ToList();
            if(medicion is null)
            {
                return NotFound("No hay mediciones registradas");
            }
            return Ok(medicion);
        }
        catch
        {
            return StatusCode(500, "Error en el servidor");
        }
    }

    [HttpGet("promedio-temperatura")]
    public IActionResult GetPromedioTemperatura()
    {
        try{
            if (mediciones.Count == 0)
            {
                return NotFound("No hay temperaturas registradas");
            }

            double sumaTemperaturas = 0;
            foreach (var medicion in mediciones)
            {
                sumaTemperaturas += medicion.Temperatura;
            }

            double promedio = sumaTemperaturas / mediciones.Count;
            return Ok(promedio); 
        }
        catch{
            return StatusCode(500, "Error en el servidor");
        }
    }

    [HttpGet("Temperatura-Max")]
    public IActionResult GetMax(){
        try
        {
            if (mediciones.Count == 0)
            {
                return NotFound("No hay temperaturas registradas");
            }

            double maxima = mediciones.Max(x => x.Temperatura);
            return Ok(maxima); 
        }
        catch
        {
            return StatusCode(500, "Error en el servidor");
        }
    }

    [HttpGet("Temperatura-Min")]
    public IActionResult GetMin(){
        try
        {
            if (mediciones.Count == 0)
            {
                return NotFound("No hay temperaturas registradas");
            }

            double minima = mediciones.Min(x => x.Temperatura);
            return Ok(minima); 
        }
        catch
        {
            return StatusCode(500, "Error en el servidor");
        }
    }

}
