using Microsoft.AspNetCore.Mvc;

namespace Estaciones_Meteorológicas.Controllers;

[ApiController]
[Route("[controller]")]
public class estacionController : ControllerBase
{
    private readonly ILogger<estacionController> _logger;

    private readonly List<Estacion> estaciones = new List<Estacion>
    {
        new Estacion { Id = 1, Nombre = "Estación 1", Localidad = "Localidad 1", Activa = true },
    };

    public estacionController(ILogger<estacionController> logger)
    {
        _logger = logger;
    }
 

    [HttpPost("registrar")]
    public IActionResult create([FromBody] Estacion estacion)
    {
        try
        {
            if (estacion == null)
            {
                return NotFound("La estación no puede ser nula.");
            }
            if (estacion.Id <= 0)
            {
                return BadRequest("El id de la estación debe ser mayor a 0.");
            }
            //Una estación inactiva no pueda recibir nuevas mediciones. 
            if (!estacion.Activa)
            {
                return BadRequest("La estación no puede estar inactiva.");
            }
            estaciones.Add(estacion);
            return Ok("Estación registrada correctamente.");
        }
        catch
        {
            return StatusCode(500, "Error en el servidor");
        }
    }

    [HttpGet("localidad")]
    public IActionResult GetByLocalidad(string localidad)
    {
        var estacion = estaciones.Where(x=> x.Localidad == localidad);
        if (!estacion.Any())
        {
            return NotFound("No hay estacion en esa localidad");
        }
        return Ok(estacion);
    }
}
