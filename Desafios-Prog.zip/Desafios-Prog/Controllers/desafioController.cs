using Microsoft.AspNetCore.Mvc;

namespace Desafio_Prog.Controllers;

[ApiController]
[Route("[controller]")]
public class desafioController : ControllerBase
{
    private readonly ILogger<desafioController> _logger;

    private readonly List<Desafio> desafios = new List<Desafio>
    {
        new Desafio { Id1 = 1, Titulo1 = "Desafio 1", Dificultad1 = "Facil", PuntajeMaximo1 = 100, Activo1 = true }
    };

    public desafioController(ILogger<desafioController> logger)
    {
        _logger = logger;
    }

    [HttpPost]
    public IActionResult create([FromBody] Desafio desafio)
    {
        if(desafio.Dificultad1 is null)
        {
            return NotFound("Campo dificultad vacio");
        }
        if(desafio.Titulo1 is null)
        {
            return NotFound("Campo titulo vacio");
        }
        if(desafio.PuntajeMaximo1 <= 0)
        {
            return NotFound("Campo Puntaje maximo invalido");
        }
        desafios.Add(desafio);
        return Ok("Se ha creado el desafio");
    }

    [HttpGet("Desafios activos")]
    public IActionResult GetDesafiosActivos()
    {
        var desafioActivo = desafios.Where(x => x.Activo1 == true).ToList();

        if(desafioActivo is null)
        {
            return NotFound("No hay desafios activos");
        }
        return Ok(desafioActivo);
    }

    [HttpGet("Dificultad")]
    public IActionResult GetDificultad(string dificultad)
    {
        var desafio = desafios.Where(x => x.Dificultad1 == dificultad).ToList();

        if(desafio is null)
        {
            return NotFound("No hay desafios con esa dificultad");
        }
        return Ok(desafio);
    }

    [HttpGet("Promedio de puntaje")]
    public IActionResult GetPromedioPuntaje()
    {
        if(desafios.Count == 0)
        {
            return NotFound("No hay desafios registrados");
        }
        var promedio = desafios.Average(x => x.PuntajeMaximo1);
        return Ok(promedio);
    }


}
