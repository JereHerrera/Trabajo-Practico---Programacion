using Microsoft.AspNetCore.Mvc;

namespace participante_Prog.Controllers;

[ApiController]
[Route("[controller]")]
public class resolucionController : ControllerBase
{
    
    private readonly ILogger<resolucionController> _logger;

    private readonly List<Participante> participantes = new List<Participante>
    {
        new Participante { Id1 = 1, Nombre1 = "Juan", Email1 = "juan@example.com" },
        new Participante { Id1 = 2, Nombre1 = "Ana", Email1 = "ana@example.com" }
    };

    private readonly List<Desafio> desafios = new List<Desafio>
    {
        new Desafio { Id1 = 1, Titulo1 = "Desafio 1", Dificultad1 = "Facil", PuntajeMaximo1 = 100, Activo1 = true },
        new Desafio { Id1 = 2, Titulo1 = "Desafio 2", Dificultad1 = "Medio", PuntajeMaximo1 = 200, Activo1 = false }
    };

    private readonly List<Resolucion> resoluciones = new List<Resolucion>
    {
        new Resolucion { Id1 = 1, DesafioId1 = 1, ParticipanteId1 = 1, PuntajeObtenido1 = 80 }
    };

    public resolucionController(ILogger<resolucionController> logger)
    {
        _logger = logger;
    }

     
    [HttpPost]
    public IActionResult create([FromBody] Resolucion resolucion)
    {
        try
        {
            if(resolucion.DesafioId1 <= 0)
            {
                return NotFound("El campo DesafioId no puede ser nulo");
            }
            if(resolucion.ParticipanteId1 <= 0)
            {
                return NotFound("El campo ParticipanteId no puede ser nulo");
            }
            if(resolucion.PuntajeObtenido1 < 0)
            {
                return NotFound("El campo PuntajeObtenido no puede ser nulo");
            }

            var participanteExiste = participantes.Any(p => p.Id1 == resolucion.ParticipanteId1);
            if(!participanteExiste)
            {
                return NotFound("El participante no existe");
            }

            var desafioExiste = desafios.Any(d => d.Id1 == resolucion.DesafioId1);
            if(!desafioExiste)
            {
                return NotFound("El desafio no existe");
            }

            var desafio = desafios.FirstOrDefault(d => d.Id1 == resolucion.DesafioId1);
            if(desafio.Activo1 == false)
            {
                return NotFound("No se pueden registrar soluciones en desafios inactivos");
            }

            if(resolucion.PuntajeObtenido1 > desafio.PuntajeMaximo1)
            {
                return NotFound("El puntaje no puede superar el maximo establecido");
            }

            var yaResolvio = resoluciones.Any(r => r.ParticipanteId1 == resolucion.ParticipanteId1 && r.DesafioId1 == resolucion.DesafioId1);
            if(yaResolvio)
            {
                return NotFound("Un participante no puede resolver dos veces el mismo desafio");
            }

            resoluciones.Add(resolucion);
            return Ok("Resolucion registrada");
        }
        catch
        {
            return StatusCode(500, ("Error en el servidor"));
        }
    }

    [HttpGet("participante/{id}")]
    public IActionResult getByParticipante(int id)
    {
        if(id <= 0)
        {
            return NotFound("El id del participante no puede ser nulo");
        }
        var resolucionesParticipante = resoluciones.Where(r => r.ParticipanteId1 == id).ToList();
        return Ok(resolucionesParticipante);
    }

}
