using System.Runtime.ExceptionServices;
using Microsoft.AspNetCore.Mvc;

namespace participante_Prog.Controllers;

[ApiController]
[Route("[controller]")]
public class participanteController : ControllerBase
{
    private readonly ILogger<participanteController> _logger;

    private readonly List<Participante> participantes = new List<Participante>
    {
        new Participante { Id1 = 1, Nombre1 = "Juan", Email1 = "juan@example.com" },
        new Participante { Id1 = 2, Nombre1 = "Ana", Email1 = "ana@example.com" }
    };

    private readonly List<Resolucion> resoluciones = new List<Resolucion>
    {
        new Resolucion { Id1 = 1, ParticipanteId1 = 1, DesafioId1 = 1, PuntajeObtenido1 = 80 },
        new Resolucion { Id1 = 2, ParticipanteId1 = 1, DesafioId1 = 2, PuntajeObtenido1 = 60 },
        new Resolucion { Id1 = 3, ParticipanteId1 = 2, DesafioId1 = 3, PuntajeObtenido1 = 95 },
        new Resolucion { Id1 = 4, ParticipanteId1 = 2, DesafioId1 = 4, PuntajeObtenido1 = 30 }
    };

    public participanteController(ILogger<participanteController> logger)
    {
        _logger = logger;
    }

    [HttpPost]
    public IActionResult create([FromBody] Participante participante)
    {
        try
        {
            if(participante.Email1 is null)
            {
                return NotFound("El campo email no puede ser nulo");
            }
            if(participantes.Any(p => p.Email1 == participante.Email1))
            {
                return NotFound("El email del participante no puede repetirse");
            }
            if(participante.Nivel1 == null)
            {
                return NotFound("El campo nivel no puede ser nulo");
            }
            if(participante.Nombre1 is null)
            {
                return NotFound("El campo nombre no puede ser nulo");
            }
            participantes.Add(participante);
            return Ok("Participante registrado");
        }
        catch
        {
            return StatusCode(500, ("Error en el servidor"));
        }
    }
 
    [HttpGet("puntaje/{puntaje}")]
    public IActionResult getByPuntaje(int puntaje)
    {
        if(puntaje <= 0)
        {
            return NotFound("El puntaje no puede ser nulo");
        }
        var participantesPuntaje = participantes.Where(p => p.Nivel1 >= puntaje).ToList();
        return Ok(participantesPuntaje);
    }


    [HttpGet("Orden Puntajes")]
    public IActionResult GetPuntaje()
    {
        if(participantes.Count == 0)
        {
            return NotFound("No hay participantes registrados");
        }

        if(resoluciones.Count == 0)
        {
            return NotFound("No hay resoluciones registradas");
        }

        var ranking = new List<dynamic>();

        foreach (var participante in participantes)
        {
            int puntajeTotal = 0;

            foreach (var resolucion in resoluciones)
            {
                if(resolucion.ParticipanteId1 == participante.Id1)
                {
                    puntajeTotal += resolucion.PuntajeObtenido1;
                }
            }

            ranking.Add(new
            {
                idParticipante = participante.Id1,
                nombre = participante.Nombre1,
                puntajeTotal = puntajeTotal
            });
        }

        ranking = ranking.OrderByDescending(x => x.puntajeTotal).ToList();

        return Ok(ranking);
    }


}
