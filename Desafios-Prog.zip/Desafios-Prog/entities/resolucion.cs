public class Resolucion
{
    //● Id ● ParticipanteId ● DesafioId ● PuntajeObtenido ● FechaEntrega
    private int Id;
    private int ParticipanteId;
    private int DesafioId;
    private int PuntajeObtenido;
    private DateTime FechaEntrega;

    public int Id1 { get => Id; set => Id = value; }
    public int ParticipanteId1 { get => ParticipanteId; set => ParticipanteId = value; }
    public int DesafioId1 { get => DesafioId; set => DesafioId = value; }
    public int PuntajeObtenido1 { get => PuntajeObtenido; set => PuntajeObtenido = value; }
    public DateTime FechaEntrega1 { get => FechaEntrega; set => FechaEntrega = value; }
}