public class Desafio
{
    private int Id;
    private string Titulo;
    private string Dificultad;
    private int PuntajeMaximo;
    private bool Activo;

    public int Id1 { get => Id; set => Id = value; }
    public string Titulo1 { get => Titulo; set => Titulo = value; }
    public string Dificultad1 { get => Dificultad; set => Dificultad = value; }
    public int PuntajeMaximo1 { get => PuntajeMaximo; set => PuntajeMaximo = value; }
    public bool Activo1 { get => Activo; set => Activo = value; }
}