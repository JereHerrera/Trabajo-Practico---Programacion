public class Participante
{
    private int Id;
    private string Nombre;
    private string Email;
    private int Nivel;

    public int Id1 { get => Id; set => Id = value; }
    public string Nombre1 { get => Nombre; set => Nombre = value; }
    public string Email1 { get => Email; set => Email = value; }
    public int Nivel1 { get => Nivel; set => Nivel = value; }
}
