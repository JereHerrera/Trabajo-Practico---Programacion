public class Mision
{
    private int id;
    private int droneId;
    private string descripcion;
    private double distanciaKm;
    private DateTime fecha;
    private string estado = "Pendiente";

    public int Id { get => id; set => id = value; }
    public int DroneId { get => droneId; set => droneId = value; }
    public string Descripcion { get => descripcion; set => descripcion = value; }
    public double DistanciaKm { get => distanciaKm; set => distanciaKm = value; }
    public DateTime Fecha { get => fecha; set => fecha = value; }
    public string Estado { get => estado; set => estado = value; }
}