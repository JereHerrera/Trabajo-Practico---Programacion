public class Drone
{
    private int id;
    private string codigo;
    private string modelo;
    private double bateria;
    private string estado;

    public int Id { get => id; set => id = value; }
    public string Codigo { get => codigo; set => codigo = value; }
    public string Modelo { get => modelo; set => modelo = value; }
    public double Bateria { get => bateria; set => bateria = value; }
    public string Estado { get => estado; set => estado = value; }
}