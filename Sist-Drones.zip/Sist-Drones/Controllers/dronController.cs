using Microsoft.AspNetCore.Mvc;

namespace Sist_Drones.Controllers;

[ApiController]
[Route("[controller]")]
public class dronController : ControllerBase
{
    private readonly List <Drone> drones = new List<Drone>
    {
        new Drone { Id = 1, Codigo = "DRN001", Modelo = "DJI Phantom 4", Bateria = 85.5, Estado = "Disponible" },
    };

    private readonly List <Mision> misiones = new List<Mision>
    {
        new Mision { Id = 1, DroneId = 1, Descripcion = "Entrega de paquete", DistanciaKm = 5.2, Fecha = DateTime.Now, Estado = "Pendiente" },
    };
    private readonly ILogger<dronController> _logger;

    public dronController(ILogger<dronController> logger)
    {
        _logger = logger;
    }

    [HttpGet("Disponibles")]
    public IActionResult GetDisponibles()
    {
        try
        {
            var dronDisponible = drones.Where(d => d.Estado == "Disponible");
            if (dronDisponible is null)
            {
                return NotFound("No hay drones disponibles");
            }
            return Ok(dronDisponible);
        }
        catch
        {
            return StatusCode(500, "Error del servidor");
        }
    }

    [HttpGet("Bateria")]
    public IActionResult GetBateria(double bateria)
    {
        try
        {
            var dronBateria = drones.Where(x => x.Bateria == bateria);
            if(dronBateria is null)
            {
                return NotFound("No hay drones con esa bateria");
            }
            return Ok(dronBateria);
        }
        catch
        {
            return StatusCode(500, "Error del servidor");
        }
    }

    [HttpGet("modelo")]
    public IActionResult GetModelo(string modelo)
    {
        try
        {
            var dronModelo = drones.Where(x => x.Modelo == modelo);
            if(dronModelo is null)
            {
                return NotFound("No hay un dron con ese modelo");
            }
            return Ok(dronModelo);
        }
        catch
        {
            return StatusCode(500, "Error del servidor");
        }
    }

    [HttpPost("Misiones")]
    public IActionResult AsignarMision(int idDrone, [FromBody] Mision mision)
    {
        try
        {
            var dron = drones.FirstOrDefault(x => x.Id == idDrone);
            if (dron is null)
            {
                return NotFound("No existe un dron con ese id");
            }

            if (dron.Estado != "Disponible")
            {
                return NotFound("Este dron no está disponible");
            }

            if (dron.Bateria < 30)
            {
                return NotFound("El dron debe tener como mínimo 30% de batería");
            }

            var misionActiva = misiones.Any(x => x.DroneId == idDrone && x.Estado != "Finalizado");
            if (misionActiva)
            {
                return BadRequest("El dron ya tiene una misión activa");
            }

            mision.DroneId = idDrone;
            misiones.Add(mision);
            return Ok("Misión asignada correctamente");
        }
        catch
        {
            return StatusCode(500, "Error del servidor");
        }
    }

    [HttpPut("Misiones/{id}/Finalizar")]
    public IActionResult update(int id)
    {
        try
        {
            var mision = misiones.FirstOrDefault(x => x.Id == id);
            if (mision is null)
            {
                return NotFound("Misión no encontrada");
            }

            if (mision.Estado == "Finalizado")
            {
                return BadRequest("La misión ya está finalizada");
            }

            var dron = drones.FirstOrDefault(x => x.Id == mision.DroneId);
            if (dron is null)
            {
                return NotFound("No se encontró el drone asociado a la misión");
            }

            mision.Estado = "Finalizado";
            dron.Estado = "Disponible";
            return Ok("Misión finalizada correctamente");
        }
        catch
        {
            return StatusCode(500, "Error del servidor");
        }
    }


    [HttpGet("{idDrone}/Misiones")]
    public IActionResult GetMisionesPorDrone(int idDrone)
    {
        try
        {
            var dron = drones.FirstOrDefault(x => x.Id == idDrone);
            if (dron is null)
            {
                return NotFound("No existe un dron con ese id");
            }

            var misionesRealizadas = misiones.Where(x => x.DroneId == idDrone && x.Estado == "Finalizado").ToList();

            if (misionesRealizadas.Count == 0)
            {
                return NotFound("Este dron no tiene misiones finalizadas");
            }

            return Ok(misionesRealizadas);
        }
        catch
        {
            return StatusCode(500, "Error del servidor");
        }
    }

    [HttpGet("Recorrido Maximo")]
    public IActionResult GetRecorridoMaximo()
    {
        try
        {
            int idDronMayor = 0;
            double mayorDistancia = 0;

            foreach (var dron in drones)
            {
                var distanciaTotal = misiones.Where(mision => mision.DroneId == dron.Id).Sum(mision => mision.DistanciaKm);

                if (idDronMayor == 0 || distanciaTotal > mayorDistancia)
                {
                    idDronMayor = dron.Id;
                    mayorDistancia = distanciaTotal;
                }
            }

            if (idDronMayor == 0)
            {
                return NotFound("No hay drones registrados");
            }

            return Ok(new
            {
                DroneId = idDronMayor,
                DistanciaTotalKm = mayorDistancia
            });
        }
        catch
        {
            return StatusCode(500, "Error del servidor");
        }
    }

    [HttpGet("Porcentaje de Bateria")]
    public IActionResult GetBateria()
    {
        try
        {
            if(drones.Count == 0)
            {
                return NotFound("No hay drones registrados");
            }

            var dronBateria = drones.Average(x => x.Bateria);
            return Ok(dronBateria);
        }
        catch
        {
            return StatusCode(500, "Error del servidor");
        }
    }

    [HttpGet("Misiones Pendientes")]
    public IActionResult GetMisionPendiente()
    {
        try{
            var misionPendiente = misiones.Where(x => x.Estado == "Pendiente").OrderBy(x => x.Fecha).ToList();
            if (misionPendiente is null){
                return NotFound("No hay misiones pendientes");
            }
            return Ok(misionPendiente);
        }
        catch
        {
            return StatusCode(500, "Error del servidor");
        }
    }

}
