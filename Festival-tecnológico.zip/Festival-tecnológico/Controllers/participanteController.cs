using Microsoft.AspNetCore.Mvc;

namespace Festival_tecnológico.Controllers;

[ApiController]
[Route("[controller]")]
public class participanteController : ControllerBase
{
    private readonly List<Participante> participantes = new List<Participante>
    {
        new Participante { Id = 1, Nombre = "Juan Pérez", Email = "juan.perez@example.com" }
    };

    private readonly List<Reserva> reservas = new();

    private readonly ILogger<participanteController> _logger;

    public participanteController(ILogger<participanteController> logger)
    {
        _logger = logger;
    }

    //Asignar exploradores a expediciones, agreagar participante a la lista de reservas de la actividad con la actividad
    [HttpPost("asignarExploradorAExpedicion")] 
    public IActionResult AsignarExploradorAExpedicion(int participanteId, int actividadId)
    {
        var participante = participantes.FirstOrDefault(p => p.Id == participanteId);
        if (participante == null)
        {
            return NotFound("Participante no encontrado.");
        }

        var actividad = new Actividad { Id = actividadId }; // Aquí deberías obtener la actividad real desde tu fuente de datos
        if (actividad == null)
        {
            return NotFound("Actividad no encontrada.");
        }

        //agrega el participante y la actividad a la lista de reservas
        reservas.Add(new Reserva { Participante = participante, Actividad = actividad });

        return Ok($"Explorador {participante.Nombre} asignado a la actividad {actividad.Id}.");
    }


   
}
