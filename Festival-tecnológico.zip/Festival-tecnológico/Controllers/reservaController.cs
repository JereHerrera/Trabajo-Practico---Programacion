using Microsoft.AspNetCore.Mvc;

namespace Festival_tecnológico.Controllers;

[ApiController]
[Route("[controller]")]
public class reservaController : ControllerBase
{

    private readonly ILogger<reservaController> _logger;

    public reservaController(ILogger<reservaController> logger)
    {
        _logger = logger;
    }

    private readonly List<ReservaActividad> reservas = new List<ReservaActividad>
    {
        new ReservaActividad { Id = 1, ActividadId = 1, ParticipanteId = 1, FechaReserva = DateTime.Now }
    };

    
}
