using Microsoft.AspNetCore.Mvc;

namespace Festival_tecnológico.Controllers;

[ApiController]
[Route("[controller]")]
public class actividadController : ControllerBase
{

    private readonly List<Actividad> actividades = new List<Actividad>
    {
        new Actividad { Id = 1, Nombre = "Taller de Robótica", Tipo = "Tecnología", Horario = DateTime.Parse("2023-07-01 10:00"), DuracionMinutos = 120, Capacidad = 20, Activa = true }
    };

    private readonly ILogger<actividadController> _logger;

    public actividadController(ILogger<actividadController> logger)
    {
        _logger = logger;
    }

   
}
