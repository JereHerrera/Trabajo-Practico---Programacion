public class ReservaActividad
{
	private int id;
	private int actividadId;
	private int participanteId;
	private DateTime fechaReserva;

    private readonly List<ReservaActividad> reservas = new List<ReservaActividad>
    {
        new ReservaActividad { Id = 1, ActividadId = 1, ParticipanteId = 1, FechaReserva = DateTime.Now }
    };

    public int Id { get => id; set => id = value; }
    public int ActividadId { get => actividadId; set => actividadId = value; }
    public int ParticipanteId { get => participanteId; set => participanteId = value; }
    public DateTime FechaReserva { get => fechaReserva; set => fechaReserva = value; }

    public List<ReservaActividad> Reservas => reservas;
}
