namespace sist_expedicion.entities;

public class expedicion
{
	private int Id;
	private string Nombre;
	private string Destino;
	private DateTime FechaInicio;
	private DateTime FechaFin;
	private int Capacidad;
	private string Estado;

    private List <explorador> exploradores = new();

    public int Id1 { get => Id; set => Id = value; }
    public string Nombre1 { get => Nombre; set => Nombre = value; }
    public string Destino1 { get => Destino; set => Destino = value; }
    public DateTime FechaInicio1 { get => FechaInicio; set => FechaInicio = value; }
    public DateTime FechaFin1 { get => FechaFin; set => FechaFin = value; }
    public int Capacidad1 { get => Capacidad; set => Capacidad = value; }
    public string Estado1 { get => Estado; set => Estado = value; }
    public List<explorador> Exploradores { get => exploradores; set => exploradores = value; }
}
