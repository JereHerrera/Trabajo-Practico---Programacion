namespace sist_expedicion.entities;

public class explorador
{
	private int Id;
	private string Nombre;
	private string Especialidad;
	private int ExperienciaAnios;
	private bool Disponible;

    public int Id1 { get => Id; set => Id = value; }
    public string Nombre1 { get => Nombre; set => Nombre = value; }
    public string Especialidad1 { get => Especialidad; set => Especialidad = value; }
    public int ExperienciaAnios1 { get => ExperienciaAnios; set => ExperienciaAnios = value; }
    public bool Disponible1 { get => Disponible; set => Disponible = value; }
}
