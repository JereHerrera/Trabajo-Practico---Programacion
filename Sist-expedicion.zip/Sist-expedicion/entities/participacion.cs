namespace sist_expedicion.entities;

public class participacion
{
	private int Id;
	private int ExpedicionId;
	private int ExploradorId;
	private string Rol;

    public int Id1 { get => Id; set => Id = value; }
    public int ExpedicionId1 { get => ExpedicionId; set => ExpedicionId = value; }
    public int ExploradorId1 { get => ExploradorId; set => ExploradorId = value; }
    public string Rol1 { get => Rol; set => Rol = value; }
}
