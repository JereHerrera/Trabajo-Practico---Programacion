using Microsoft.AspNetCore.Mvc;
using sist_expedicion.entities;

namespace sist_expedicion.Controllers;

[ApiController]
[Route("[controller]")]
public class exploradorController : ControllerBase
{
    private static readonly List<explorador> exploradores = new List<explorador>
    {
        new explorador { Id1 = 1, Nombre1 = "Juan", Especialidad1 = "Montañismo", ExperienciaAnios1 = 5, Disponible1 = true },
    };

    private static readonly List<participacion> participaciones = new List<participacion>
    {
        new participacion { Id1 = 1, ExpedicionId1 = 1, ExploradorId1 = 1, Rol1 = "Líder" },
    };

    private static readonly List<expedicion> expediciones = new List<expedicion>
    {
        new expedicion { Id1 = 1, Nombre1 = "Expedición A", Destino1 = "Montaña X", FechaInicio1 = new DateTime(2023, 6, 1), FechaFin1 = new DateTime(2023, 6, 10), Capacidad1 = 10, Estado1 = "En curso" },
        new expedicion { Id1 = 2, Nombre1 = "Expedición B", Destino1 = "Volcán Y", FechaInicio1 = new DateTime(2024, 7, 5), FechaFin1 = new DateTime(2024, 7, 15), Capacidad1 = 8, Estado1 = "Planificada" },
    };

    [HttpPost("Registrar Explorador")]
    public IActionResult create(int ExpedicionId,int ExploradorId,[FromBody] participacion participacion)
    {
        var explorador = exploradores.FirstOrDefault(x => x.Id1 == ExploradorId);
        if (explorador is null)
        {
            return NotFound("No se encontro ese explorador");
        }
        var expedicion = expediciones.FirstOrDefault(x => x.Id1 == ExpedicionId);
        if (expedicion is null)
        {
            return NotFound("No se encontro esa expedicion");
        }

        expedicion.Exploradores.Add(explorador);
        return Ok("Explorador asigando");
    }

    [HttpGet("Integrantes/expedision")]
    public IActionResult GetIntegrantesExpedicion(int id)
    {
        var expedicion = expediciones.FirstOrDefault(x => x.Id1 ==id);
        if (expedicion is null)
        {
            return NotFound("No se encontro esa expedicion");
        }
        if(expedicion.Exploradores is null)
        {
            return NotFound("No hay exploradores en esta expedicion");
        }

        return Ok(expedicion.Exploradores);
    }

    [HttpGet("Explorador{id}/expedicion")]
    public IActionResult GetExploradorExpedicion(int id)
    {
        var exploradorBuscado = exploradores.FirstOrDefault(x => x.Id1 == id);
        if (exploradorBuscado is null)
        {
            return NotFound("explorador inexistente");
        }
        List<expedicion> listaExpeEsplo = new List<expedicion>();
        foreach(expedicion a in expediciones)
        {
            foreach(explorador b in a.Exploradores)
            {
                if (b == exploradorBuscado)
                {
                    listaExpeEsplo.Add(a);
                }
            }
        }
        return Ok(listaExpeEsplo);
    }


}
