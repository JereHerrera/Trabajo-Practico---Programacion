using Microsoft.AspNetCore.Mvc;

namespace Monitoreo_espacial.Controllers;

[ApiController]
[Route("[controller]")]
public class WeatherForecastController : ControllerBase
{

    private readonly ILogger<WeatherForecastController> _weatherLogger;

    public WeatherForecastController(ILogger<WeatherForecastController> logger)
    {
        _weatherLogger = logger;
    }

}
