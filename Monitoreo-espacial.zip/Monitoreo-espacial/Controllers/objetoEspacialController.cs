using Microsoft.AspNetCore.Mvc;
using Monitoreo_espacial.entities;

namespace Monitoreo_espacial.Controllers;

[ApiController]
[Route("[controller]")]
public class objetoEspacialController : ControllerBase
{
    private readonly List<objetoEspacial> objetosEspaciales = new List<objetoEspacial>
    {
        new objetoEspacial { Id1 = 1, Nombre1 = "Asteroide A", Tipo1 = "Asteroide", Distancia1 = 1000000, NivelRiesgo1 = 3, FechaDescubrimiento1 = new DateTime(2020, 5, 10), Activo1 = true }
    };

    private readonly List<observacion> observaciones = new List<observacion>
    {
        new observacion { Id1 = 1, ObjetoEspacialId1 = 1, Fecha1 = new DateTime(2023, 8, 15), DistanciaMedida1 = 950000, Velocidad1 = 25000, Comentario1 = "Observación inicial del asteroide." }
    };

    private readonly ILogger<objetoEspacialController> _logger;

    public objetoEspacialController(ILogger<objetoEspacialController> logger)
    {
        _logger = logger;
    }

    [HttpPost("registrar")]
    public ActionResult create([FromBody] objetoEspacial nuevoObjeto)
    {
        if (nuevoObjeto == null){
            return BadRequest("Debe enviar un objeto espacial.");
        } 

        var nuevoId = objetosEspaciales.Count == 0 ? 1 : objetosEspaciales.Max(x => x.Id1) + 1;
        nuevoObjeto.Id1 = nuevoId;
        objetosEspaciales.Add(nuevoObjeto);
        return Ok(nuevoObjeto);
    }

    [HttpPost("registrar-observacion")]
    public ActionResult create([FromBody] observacion nuevaObservacion)
    {
        if (nuevaObservacion == null) {
            return BadRequest("Debe enviar una observación.");
        }

        var nuevoId = observaciones.Count == 0 ? 1 : observaciones.Max(x => x.Id1) + 1;
        nuevaObservacion.Id1 = nuevoId;
        observaciones.Add(nuevaObservacion);
        return Ok(nuevaObservacion);
    }

    [HttpGet("observaciones/{objetoId}")]
    public ActionResult GetObservaciones(int objetoId)
    {
        var resultado = observaciones.Where(x => x.ObjetoEspacialId1 == objetoId).ToList();
        return Ok(resultado);
    }

    [HttpGet("buscar")]
    public ActionResult GetNombre(string nombre)
    {
        var resultado = objetosEspaciales.Where(x => x.Nombre1.Contains(nombre)).ToList();
        return Ok(resultado);
    }

    [HttpGet("tipo")]
    public ActionResult GetTipo(string tipo)
    {
        var resultado = objetosEspaciales.Where(x => x.Tipo1.Contains(tipo)).ToList();
        return Ok(resultado);
    }

    [HttpGet("riesgo")]
    public ActionResult GetRiesgo(int nivel)
    {
        var resultado = objetosEspaciales.Where(x => x.NivelRiesgo1 == nivel).ToList();
        return Ok(resultado);
    }

    [HttpGet("distancia-menor")]
    public ActionResult GetDistanciaMenor(double distancia)
    {
        var resultado = objetosEspaciales.Where(x => x.Distancia1 < distancia).ToList();
        return Ok(resultado);
    }

    [HttpGet("promedio-velocidad")]
    public ActionResult GetPromedioVelocidad()
    {
        if (observaciones.Count == 0) return Ok(0);

        double total = 0;
        foreach (var item in observaciones)
        {
            total += item.Velocidad1;
        }

        var promedio = total / observaciones.Count;
        return Ok(promedio);
    }

    [HttpGet("objeto-mas-observaciones")]
    public ActionResult GetMayorObservaciones()
    {
        if (objetosEspaciales.Count == 0) return Ok("No hay objetos registrados.");

        objetoEspacial objetoMayor = null;
        int mayorCantidad = 0;

        foreach (var objeto in objetosEspaciales)
        {
            int cantidad = 0;
            foreach (var observacionItem in observaciones)
            {
                if (observacionItem.ObjetoEspacialId1 == objeto.Id1)
                {
                    cantidad++;
                }
            }

            if (cantidad > mayorCantidad)
            {
                mayorCantidad = cantidad;
                objetoMayor = objeto;
            }
        }

        return Ok(new { Objeto = objetoMayor, CantidadObservaciones = mayorCantidad });
    }

    [HttpGet("sin-observaciones")]
    public ActionResult GetSinObservaciones()
    {
        var resultado = new List<objetoEspacial>();

        foreach (var objeto in objetosEspaciales)
        {
            bool tieneObservaciones = false;
            foreach (var observacionItem in observaciones)
            {
                if (observacionItem.ObjetoEspacialId1 == objeto.Id1)
                {
                    tieneObservaciones = true;
                    break;
                }
            }

            if (!tieneObservaciones)
            {
                resultado.Add(objeto);
            }
        }

        return Ok(resultado);
    }

    [HttpGet("ordenados-riesgo")]
    public ActionResult GetOrdenadosRiesgo()
    {
        var resultado = objetosEspaciales.OrderByDescending(x => x.NivelRiesgo1).ToList();
        return Ok(resultado);
    }

    [HttpGet("estadisticas")]
    public ActionResult GetEstadisticas()
    {
        var totalObjetos = objetosEspaciales.Count;
        var totalObservaciones = observaciones.Count;

        double sumaRiesgo = 0;
        foreach (var objeto in objetosEspaciales)
        {
            sumaRiesgo += objeto.NivelRiesgo1;
        }

        double promedioRiesgo = 0;
        if (totalObjetos != 0)
        {
            promedioRiesgo = sumaRiesgo / totalObjetos;
        }

        double sumaVelocidad = 0;
        foreach (var item in observaciones)
        {
            sumaVelocidad += item.Velocidad1;
        }

        double promedioVelocidad = totalObservaciones == 0 ? 0 : sumaVelocidad / totalObservaciones;

        int objetosActivos = 0;
        foreach (var objeto in objetosEspaciales)
        {
            if (objeto.Activo1)
            {
                objetosActivos++;
            }
        }

        var estadisticas = new
        {
            TotalObjetos = totalObjetos,
            TotalObservaciones = totalObservaciones,
            ObjetosActivos = objetosActivos,
            PromedioNivelRiesgo = promedioRiesgo,
            PromedioVelocidad = promedioVelocidad
        };

        return Ok(estadisticas);
    }
}
