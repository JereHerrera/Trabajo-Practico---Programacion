namespace Monitoreo_espacial.entities;

public class observacion
{
    private int Id;
    private int ObjetoEspacialId;
    private DateTime Fecha;
    private double DistanciaMedida;
    private double Velocidad;
    private string Comentario;

    public int Id1 { get => Id; set => Id = value; }
    public int ObjetoEspacialId1 { get => ObjetoEspacialId; set => ObjetoEspacialId = value; }
    public DateTime Fecha1 { get => Fecha; set => Fecha = value; }
    public double DistanciaMedida1 { get => DistanciaMedida; set => DistanciaMedida = value; }
    public double Velocidad1 { get => Velocidad; set => Velocidad = value; }
    public string Comentario1 { get => Comentario; set => Comentario = value; }
}
