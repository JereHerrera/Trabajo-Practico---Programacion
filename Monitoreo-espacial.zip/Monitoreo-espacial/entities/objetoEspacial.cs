public class objetoEspacial
{
    private int Id;
    private string Nombre;
    private string Tipo;
    private double Distancia;
    private int NivelRiesgo;
    private DateTime FechaDescubrimiento;
    private bool Activo;

    public int Id1 { get => Id; set => Id = value; }
    public string Nombre1 { get => Nombre; set => Nombre = value; }
    public string Tipo1 { get => Tipo; set => Tipo = value; }
    public double Distancia1 { get => Distancia; set => Distancia = value; }
    public int NivelRiesgo1 { get => NivelRiesgo; set => NivelRiesgo = value; }
    public DateTime FechaDescubrimiento1 { get => FechaDescubrimiento; set => FechaDescubrimiento = value; }
    public bool Activo1 { get => Activo; set => Activo = value; }
}
